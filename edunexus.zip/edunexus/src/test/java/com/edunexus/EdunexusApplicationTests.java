package com.edunexus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdunexusApplicationTests {

	@Test
	void contextLoads() {
	}

}
