package com.edunexus.entity;

public enum TransactionStatus {
    PENDING,
    APPROVED,
    REJECTED,
    COMPLETED
}
