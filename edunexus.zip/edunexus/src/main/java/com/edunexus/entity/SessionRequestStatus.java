package com.edunexus.entity;

public enum SessionRequestStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
    COMPLETED
}
